function run_warning_activecentral_suite(selection)
% Targeted optimizer retries: same physical problem, saved initial weights.
% Linear GPS reference; nonlinear central-difference active-set, all applicable tolerances1e-6.
if nargin<1, selection='all'; end
setup_warning_activecentral;
warning('off','backtrace');
root=fileparts(fileparts(mfilename('fullpath')));
out=fullfile(root,'research','warning-activecentral-run'); if ~isfolder(out), mkdir(out); end
examples={'optimizationBasedControl/example_optBasedContr_car.m'};
suite=testsuite(fullfile(root,'research','AROC-warning-activecentral','unitTests'));
suite=suite(startsWith({suite.Name},'testOptimizationBasedControl/'));
blank=struct('id','','kind','','source','','algorithm','','status','pending', ...
    'seconds',0,'checks',struct,'figures',{{}},'error','','exportNotes','');
cases=repmat(blank,1,numel(examples)+numel(suite));
for k=1:numel(examples)
    [folder,name]=fileparts(examples{k});
    cases(k).id=name; cases(k).kind='example'; cases(k).source=['examples/' examples{k}]; cases(k).algorithm=folder;
end
for k=1:numel(suite)
    j=numel(examples)+k; cases(j).id=regexprep(suite(k).Name,'[^A-Za-z0-9_-]','_');
    cases(j).kind='unit-test'; cases(j).source=suite(k).Name; cases(j).algorithm=extractBefore(suite(k).Name,'/');
end
report=struct('date',char(datetime('now','Format','yyyy-MM-dd')),'matlab',version,'seed',20261019, ...
    'AROCCommit','6ba0295754d935b2bf540fab904ebc235a2d7a5c', ...
    'CORA','v2026.0.1','YALMIP','R20250626','CasADi','3.7.2', ...
    'convexSolver','MOSEK 11.0 available; GPS2N for linear; active-set central differences eps^(1/3) for nonlinear, 1800 s callback guard, function/step/constraint tolerances1e-6, maxIter=250, saved weights, mesh/function/step/constraint tolerances 1e-6', ...
    'mosekAvailability','Renewed license: fresh MATLAB process solved successfully (code 0)', ...
    'exampleCount',numel(examples),'unitTestCount',numel(suite),'cases',cases);
manifest=fullfile(out,'manifest.json');
if isfile(manifest)
    previous=jsondecode(fileread(manifest));
    for k=1:numel(cases)
        old=find(strcmp({previous.cases.id},cases(k).id),1);
        if ~isempty(old) && ~strcmp(previous.cases(old).status,'running')
            cases(k)=previous.cases(old);
        end
    end
end
report.cases=cases; write_manifest(manifest,report);
fprintf('FULL RUN: %d examples + %d unit-test sections\n',numel(examples),numel(suite));
for k=1:numel(cases)
    if ~strcmp(cases(k).status,'pending') && ~strcmp(selection,cases(k).id), continue; end
    if ~strcmp(selection,'all') && ~strcmp(selection,cases(k).id) && ~strcmp(selection,cases(k).kind), continue; end
    caseDir=fullfile(out,cases(k).id); if ~isfolder(caseDir), mkdir(caseDir); end
    diary(fullfile(caseDir,'run.log'));
    cases(k).figures={};cases(k).checks=struct;cases(k).error='';cases(k).exportNotes='';
    cases(k).status='running'; report.cases=cases; write_manifest(manifest,report);
    fprintf('\nCASE %d/%d %s\n',k,numel(cases),cases(k).id);
    rng(20261019,'twister'); close all force;
    % Each separately invoked MATLAB test restores its incoming path. CORA
    % may reuse derivative files from a preceding case without adding their
    % directory again, so refresh only the generated-function search path.
    addpath(genpath(fullfile(root,'research','CORA-warning-activecentral','models','auxiliary')));
    rehash;
    setenv('AROC_OPTIM_TRACE_DIR',caseDir);
    prepare_initial_weights(root,out,cases(k).id,caseDir);
    setenv('AROC_OPTIM_WARMSTART',fullfile(caseDir,'initial-weights.mat'));
    started=tic;
    try
        if strcmp(cases(k).kind,'example')
            snapshot=execute_script(fullfile(root,'research','AROC-warning-activecentral',cases(k).source));
            cases(k).status='executed';
            cases(k).checks=check_snapshot(snapshot);
            save(fullfile(caseDir,'workspace.mat'),'-struct','snapshot','-v7.3');
            figs=findall(groot,'Type','figure');
            for n=1:numel(figs)
                figureFile=sprintf('figure-%02d',n);
                try
                    set(figs(n),'Color','white');
                    exportgraphics(figs(n),fullfile(caseDir,[figureFile '.png']),'Resolution',180);
                    print(figs(n),fullfile(caseDir,[figureFile '.svg']),'-dsvg');
                    cases(k).figures{end+1}=[figureFile '.png'];
                catch exportError
                    cases(k).exportNotes=[cases(k).exportNotes newline getReport(exportError,'basic','hyperlinks','off')];
                end
            end
        else
            testIndex=k-numel(examples);
            testResult=run(suite(testIndex));
            save(fullfile(caseDir,'test-result.mat'),'testResult');
            cases(k).checks=struct('passed',testResult.Passed,'failed',testResult.Failed,'incomplete',testResult.Incomplete);
            if testResult.Passed, cases(k).status='passed'; else, cases(k).status='failed'; end
            cases(k).error=evalc('disp(testResult)');
        end
        diag=jsondecode(fileread(fullfile(caseDir,'solver-diagnostics.json')));
        assert(diag.exitflag>0 && diag.constraintViolation<=diag.constraintTolerance,'Optimizer did not finish successfully with feasible constraints');
    catch err
        cases(k).status='failed'; cases(k).error=getReport(err,'extended','hyperlinks','off'); disp(cases(k).error);
    end
    cases(k).seconds=toc(started);
    report.cases=cases; write_manifest(manifest,report);
    fid=fopen(fullfile(caseDir,'status.json'),'w'); fprintf(fid,'%s',jsonencode(cases(k),PrettyPrint=true)); fclose(fid);
    fprintf('CASE RESULT: %s %s (%.1f s)\n',cases(k).id,cases(k).status,cases(k).seconds);
    diary off;
end
disp('FULL RUN REACHED END');
end

function snapshot=execute_script(source)
run(source);
names=who; snapshot=struct;
for q=1:numel(names)
    if ~ismember(names{q},{'source','names','snapshot','q'})
        snapshot.(names{q})=eval(names{q});
    end
end
end

function checks=check_snapshot(s)
checks=struct;
if isfield(s,'Param') && isfield(s.Param,'U')
    for name={'resSim','res','result'}
        key=name{1};
        if isfield(s,key) && isa(s.(key),'results') && ~isempty(s.(key).simulation)
            ok=logical(checkSimInputs(s.(key),s.Param.U));
            checks.([key '_sampledInputConstraints'])=ok;
            assert(ok,'Sampled input constraint check failed');
        end
    end
end
if isfield(s,'resSim') && isa(s.resSim,'results')
    if isfield(s,'resLin'), name='resLin'; else, name='res'; end
    if isfield(s,name) && isa(s.(name),'results') && ~isempty(s.(name).reachSetTimePoint)
        combined=add(s.(name),s.resSim);
        ok=logical(checkFinalSimPoints(combined)); checks.sampledEndpointsInReachSet=ok;
        assert(ok,'Sampled endpoint reach-set check failed');
    end
end
end

function write_manifest(path,report)
fid=fopen(path,'w'); fprintf(fid,'%s',jsonencode(report,PrettyPrint=true)); fclose(fid);
end

function prepare_initial_weights(root,out,id,caseDir)
if isfile(fullfile(caseDir,'initial-weights.mat')), return; end
if strcmp(id,'testOptimizationBasedControl_TestLinearSystem')
    source=fullfile(root,'research/warning-opt-run',id,'solver-diagnostics.mat');
    provenance='SQP 250-iteration retry of the same linear benchmark';
elseif strcmp(id,'example_optBasedContr_car')
    source=fullfile(root,'research/warning-opt-run',id,'solver-diagnostics.mat');
    provenance='Saved SQP solution of the same nonlinear car benchmark';
    if ~isfile(source)
        source=fullfile(root,'research/warning-opt-run',id,'feasible-checkpoint.mat');
        if ~isfile(source), source=fullfile(root,'research/warning-opt-run',id,'optimizer-checkpoint.mat'); end
        provenance='Saved SQP checkpoint of the same nonlinear car benchmark';
    end
else
    source=fullfile(out,'example_optBasedContr_car','solver-diagnostics.mat');
    provenance='Accepted car example of this numerical variant; identical physical optimization options';
end
saved=load(source);
if isfield(saved,'xOpt'), xInit=saved.xOpt; else, xInit=saved.x; end
save(fullfile(caseDir,'initial-weights.mat'),'xInit');
info=struct('provenance',provenance,'weights',xInit);
if isfield(saved,'values'), info.checkpointIteration=saved.values.iteration; end
fid=fopen(fullfile(caseDir,'initial-weights.json'),'w');fprintf(fid,'%s',jsonencode(info,PrettyPrint=true));fclose(fid);
end
