function export_plot_data(force)
if nargin<1, force=false; end
% Export numeric set geometry and at most 10 recorded simulations per result.
% Original full workspaces remain in each case directory.
setup_full_run; warning('off','all');
root=fileparts(fileparts(mfilename('fullpath')));
folder=fullfile(root,'research','full-run');
report=jsondecode(fileread(fullfile(folder,'manifest.json')));
for k=1:numel(report.cases)
    item=report.cases(k); input=fullfile(folder,item.id,'workspace.mat');
    output=fullfile(folder,item.id,'plot-data.mat');
    if ~strcmp(item.status,'executed') || ~isfile(input) || (isfile(output) && ~force), continue; end
    original=load(input); names=fieldnames(original); data=struct;
    for j=1:numel(names)
        if ~isempty(regexp(names{j},'^(Param|Opts|res|result|sim|T($|_)|terminalRegion|Wint|Vint|Wzono|Vzono|M$|R$)','once'))
            data.(names{j})=numeric_data(original.(names{j}),0);
        end
    end
    data.exportNote='Time-point set geometry and at most 10 recorded simulations per results object. Full continuous-time tubes and original workspaces retained separately.';
    data.caseId=item.id; data.seed=20261019;
    save(output,'-struct','data','-v7'); info=dir(output);
    fprintf('%s plot-data=%d bytes\n',item.id,info.bytes);
end
end

function value=numeric_data(value,depth)
if depth>10, value=struct('omitted','Depth limit'); return; end
if isnumeric(value) || islogical(value) || ischar(value) || isstring(value), return; end
if isa(value,'function_handle'), value=func2str(value); return; end
if iscell(value)
    for k=1:numel(value), value{k}=numeric_data(value{k},depth+1); end
    return;
end
if isstruct(value)
    names=fieldnames(value);
    for q=1:numel(value)
        for k=1:numel(names), value(q).(names{k})=numeric_data(value(q).(names{k}),depth+1); end
    end
    return;
end
kind=class(value); source=value; value=struct('class',kind);
if isa(source,'results')
    count=min(10,numel(source.simulation));
    value.recordedSimulationCount=numel(source.simulation);
    value.exportedSimulationIndices=1:count;
    value.simulation=numeric_data(source.simulation(1:count),depth+1);
    value.reachSetTimePoint=numeric_data(source.reachSetTimePoint,depth+1);
    value.continuousTubeOmitted=true;
elseif isa(source,'reachSet')
    parts=struct('timePoint',{},'timeInterval',{});
    for q=1:numel(source)
        parts(q).timePoint=numeric_data(source(q).timePoint,depth+1); %#ok<AGROW>
        parts(q).timeInterval=[]; %#ok<AGROW>
    end
    value.parts=parts;
elseif isa(source,'terminalRegion')
    value.set=numeric_data(source.set,depth+1);
    if isprop(source,'termSet'), value.targetSet=numeric_data(source.termSet,depth+1); end
elseif isa(source,'zonotope') || isa(source,'polyZonotope')
    for name={'c','G','GI','E','id'}
        if isprop(source,name{1}), value.(name{1})=source.(name{1}); end
    end
elseif isa(source,'interval')
    value.lower=infimum(source); value.upper=supremum(source);
elseif isa(source,'polytope')
    for name={'A','b','Ae','be'}
        if isprop(source,name{1}), value.(name{1})=source.(name{1}); end
    end
elseif isa(source,'ellipsoid')
    value.Q=source.Q; value.q=source.q;
end
end
