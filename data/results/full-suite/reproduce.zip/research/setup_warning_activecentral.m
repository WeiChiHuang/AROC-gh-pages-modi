function setup_warning_activecentral(useMosek)
if nargin<1, useMosek=true; end
root=fileparts(fileparts(mfilename('fullpath')));
for name={'CORA-warning-activecentral','YALMIP','AROC-warning-activecentral'}
    folder=fullfile(root,'research',name{1});
    assert(isfolder(folder),'Missing dependency directory: %s',folder);
    addpath(genpath(folder));
end
addpath(fullfile(root,'research','CasADi'));
if useMosek
    folder=getenv('AROC_MOSEK_TOOLBOX');
else
    folder=getenv('AROC_SEDUMI_DIR');
end
assert(~isempty(folder) && isfolder(folder),'Set the selected solver directory environment variable first.');
addpath(genpath(folder));
set(groot,'defaultFigureVisible','off');
set(groot,'defaultAxesFontName','Arial','defaultAxesFontSize',12);
rng(20261019,'twister');
pool=gcp('nocreate');
if isempty(pool)
    cluster=parcluster('Processes');cluster.NumWorkers=4;
    pool=parpool(cluster,4);
end
end
