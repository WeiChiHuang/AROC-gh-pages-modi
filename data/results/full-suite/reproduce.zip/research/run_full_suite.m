function run_full_suite(selection)
% Checkpointed full algorithm coverage using unchanged benchmark settings.
if nargin<1, selection='all'; end
setup_full_run;
warning('off','backtrace');
root=fileparts(fileparts(mfilename('fullpath')));
out=fullfile(root,'research','full-run'); if ~isfolder(out), mkdir(out); end
examples={ ...
'optimizationBasedControl/example_optBasedContr_car.m'; ...
'convexInterpolationControl/example_convInterContr_car.m'; ...
'generatorSpaceControl/example_genSpaceContr_car.m'; ...
'polynomialControl/example_polyContr_car.m'; ...
'combinedControl/example_combinedContr_car.m'; ...
'safetyNetControl/example_safetyNetContr_car.m'; ...
'linSysMPC/example_linSysMPC_doubleIntegrator.m'; ...
'reachsetMPC/example_reachsetMPC_artificialSystem1.m'; ...
'reachsetMPC/example_reachsetMPC_stirredTankReactor1.m'; ...
'maneuverAutomaton/example_maneuverAutomaton_car1.m'; ...
'conformantSynthesis/example_conformantSynthesis_platoon.m'; ...
'conformantSynthesis/example_conformantSynthesis_car.m'; ...
'terminalRegion/example_termReg_linSys_doubleIntegrator.m'; ...
'terminalRegion/example_termReg_nonlinSysOpt_SD_cart.m'; ...
'terminalRegion/example_termReg_nonlinSysLinApproach_DT_cart.m'; ...
'terminalRegion/example_termReg_nonlinSysLinApproach_SD_robotArm.m'; ...
'terminalRegion/example_termReg_nonlinSysPolyApproach_SD_cartpole.m'; ...
'terminalRegion/example_termReg_subpaving_artificialSystem.m'};
suite=testsuite(fullfile(root,'research','AROC','unitTests'));
blank=struct('id','','kind','','source','','algorithm','','status','pending', ...
    'seconds',0,'checks',struct,'figures',{{}},'error','','exportNotes','');
cases=repmat(blank,1,numel(examples)+numel(suite));
for k=1:numel(examples)
    [folder,name]=fileparts(examples{k});
    cases(k).id=name; cases(k).kind='example'; cases(k).source=['examples/' examples{k}]; cases(k).algorithm=folder;
end
for k=1:numel(suite)
    j=numel(examples)+k; cases(j).id=regexprep(suite(k).Name,'[^A-Za-z0-9_-]','_');
    cases(j).kind='unit-test'; cases(j).source=suite(k).Name; cases(j).algorithm=extractBefore(suite(k).Name,'/');
end
report=struct('date','2026-10-19','matlab',version,'seed',20261019, ...
    'AROCCommit','6ba0295754d935b2bf540fab904ebc235a2d7a5c', ...
    'CORA','v2026.0.1','YALMIP','R20250626','CasADi','3.7.2', ...
    'convexSolver','SeDuMi 1.3; two hard-coded MOSEK selections changed locally', ...
    'mosekAvailability','MOSEK 11.0 installed; license expired (1001)', ...
    'exampleCount',numel(examples),'unitTestCount',numel(suite),'cases',cases);
manifest=fullfile(out,'manifest.json');
if isfile(manifest)
    previous=jsondecode(fileread(manifest));
    for k=1:numel(cases)
        old=find(strcmp({previous.cases.id},cases(k).id),1);
        if ~isempty(old) && ~strcmp(previous.cases(old).status,'running')
            cases(k)=previous.cases(old);
        end
    end
end
report.cases=cases; write_manifest(manifest,report);
fprintf('FULL RUN: %d examples + %d unit-test sections\n',numel(examples),numel(suite));
for k=1:numel(cases)
    if ~strcmp(cases(k).status,'pending') && ~strcmp(selection,cases(k).id), continue; end
    if ~strcmp(selection,'all') && ~strcmp(selection,cases(k).id) && ~strcmp(selection,cases(k).kind), continue; end
    caseDir=fullfile(out,cases(k).id); if ~isfolder(caseDir), mkdir(caseDir); end
    diary(fullfile(caseDir,'run.log'));
    cases(k).status='running'; report.cases=cases; write_manifest(manifest,report);
    fprintf('\nCASE %d/%d %s\n',k,numel(cases),cases(k).id);
    rng(20261019,'twister'); close all force;
    % Refresh generated derivative paths between separately invoked tests.
    addpath(genpath(fullfile(root,'research','CORA','models','auxiliary')));
    rehash;
    started=tic;
    try
        if strcmp(cases(k).kind,'example')
            snapshot=execute_script(fullfile(root,'research','AROC',cases(k).source));
            cases(k).status='executed';
            cases(k).checks=check_snapshot(snapshot);
            save(fullfile(caseDir,'workspace.mat'),'-struct','snapshot','-v7.3');
            figs=findall(groot,'Type','figure');
            for n=1:numel(figs)
                figureFile=sprintf('figure-%02d',n);
                try
                    set(figs(n),'Color','white');
                    exportgraphics(figs(n),fullfile(caseDir,[figureFile '.png']),'Resolution',180);
                    print(figs(n),fullfile(caseDir,[figureFile '.svg']),'-dsvg');
                    cases(k).figures{end+1}=[figureFile '.png'];
                catch exportError
                    cases(k).exportNotes=[cases(k).exportNotes newline getReport(exportError,'basic','hyperlinks','off')];
                end
            end
        else
            testIndex=k-numel(examples);
            testResult=run(suite(testIndex));
            save(fullfile(caseDir,'test-result.mat'),'testResult');
            cases(k).checks=struct('passed',testResult.Passed,'failed',testResult.Failed,'incomplete',testResult.Incomplete);
            if testResult.Passed, cases(k).status='passed'; else, cases(k).status='failed'; end
            cases(k).error=evalc('disp(testResult)');
        end
    catch err
        cases(k).status='failed'; cases(k).error=getReport(err,'extended','hyperlinks','off'); disp(cases(k).error);
    end
    cases(k).seconds=toc(started);
    report.cases=cases; write_manifest(manifest,report);
    fid=fopen(fullfile(caseDir,'status.json'),'w'); fprintf(fid,'%s',jsonencode(cases(k),PrettyPrint=true)); fclose(fid);
    fprintf('CASE RESULT: %s %s (%.1f s)\n',cases(k).id,cases(k).status,cases(k).seconds);
    diary off;
end
disp('FULL RUN REACHED END');
end

function snapshot=execute_script(source)
run(source);
names=who; snapshot=struct;
for q=1:numel(names)
    if ~ismember(names{q},{'source','names','snapshot','q'})
        snapshot.(names{q})=eval(names{q});
    end
end
end

function checks=check_snapshot(s)
checks=struct;
if isfield(s,'Param') && isfield(s.Param,'U')
    for name={'resSim','res','result'}
        key=name{1};
        if isfield(s,key) && isa(s.(key),'results') && ~isempty(s.(key).simulation)
            ok=logical(checkSimInputs(s.(key),s.Param.U));
            checks.([key '_sampledInputConstraints'])=ok;
            assert(ok,'Sampled input constraint check failed');
        end
    end
end
if isfield(s,'resSim') && isa(s.resSim,'results')
    if isfield(s,'resLin'), name='resLin'; else, name='res'; end
    if isfield(s,name) && isa(s.(name),'results') && ~isempty(s.(name).reachSetTimePoint)
        combined=add(s.(name),s.resSim);
        ok=logical(checkFinalSimPoints(combined)); checks.sampledEndpointsInReachSet=ok;
        assert(ok,'Sampled endpoint reach-set check failed');
    end
end
end

function write_manifest(path,report)
fid=fopen(path,'w'); fprintf(fid,'%s',jsonencode(report,PrettyPrint=true)); fclose(fid);
end
