function export_website_animations(renderScenes)
% Export saved results only. Does not run controller synthesis or simulation.
if nargin<1,renderScenes=true;end
setup_remaining_run; warning('off','all');
root=fileparts(fileparts(mfilename('fullpath')));
base=fullfile(root,'website/data/results/full-suite');out=fullfile(root,'website/data/animations');
if ~isfolder(out),mkdir(out);end
r=jsondecode(fileread(fullfile(base,'manifest.json'))); audit={};
for k=1:numel(r.cases)
 if iscell(r.cases),c=r.cases{k};else,c=r.cases(k);end
 if ~strcmp(c.kind,'example'),continue;end
 d=load(fullfile(base,c.id,'plot-data.mat'));dims=[1,2];
 a=struct('caseId',c.id,'title',c.id,'timeKind','physical','times',[0,1],...
  'xLabel','State x₁','yLabel','State x₂','series',{{}},'sets',{{}},'staticSets',{{}},'legend',{{}},'note','');
 if contains(c.id,'robotArm'),dims=[1,3];a.xLabel='Joint 1 angle [rad]';a.yLabel='Joint 1 velocity [rad/s]';
 elseif contains(c.id,'cartpole'),dims=[1,3];a.xLabel='State x₁';a.yLabel='State x₃';
 elseif contains(c.id,'stirredTank'),a.xLabel='Concentration offset C_A − 0.5';a.yLabel='Temperature offset T − 350';
 elseif contains(c.id,'platoon'),a.xLabel='Vehicle 1 position x₁';a.yLabel='Vehicle 1 velocity x₂';
 elseif contains(c.id,'doubleIntegrator'),a.xLabel='Position x₁';a.yLabel='Velocity x₂';
 elseif endsWith(c.id,'_car'),dims=[3,4];a.xLabel='x [m]';a.yLabel='y [m]';end
 alignment={};
 if strcmp(c.algorithm,'conformantSynthesis')
  m=d.M{1};a.series={trace(m.t(:),m.x(dims,:)','#c65729')};
  a.times=[min(m.t),max(m.t)];tp=d.R.parts(1).timePoint;
  for j=1:numel(tp.set),v=tp.set{j};if iscell(v),v=v{1};end;if isfield(v,'set'),v=v.set;end
   a.sets{end+1}=struct('time',tp.time{j},'points',outline(v,dims));end
  a.note='First supplied fitting trajectory and identified-model sets, aligned by recorded timestamps. This is fitting-data playback, not held-out validation.';
 elseif strcmp(c.id,'example_termReg_nonlinSysOpt_SD_cart')
  a.timeKind='sequence';a.times=[0,1];a.stepLabels={'Linearization','Polynomialization'};
  a.sets={struct('time',0,'points',outline(d.terminalRegionLin.set,dims),'color','#397cce'),struct('time',1,'points',outline(d.terminalRegionPoly.set,dims),'color','#ba5339')};
  a.note='Two saved terminal regions shown in comparison order. The sequence does not represent physical time or synthesis iterations.';
 elseif strcmp(c.algorithm,'maneuverAutomaton')
  a.frames={'maneuver-0.svg','maneuver-1.svg','maneuver-2.svg','maneuver-3.svg'};a.times=[0,1,2,3];
  a.note='Four snapshots rendered from the saved motion plan at 0, 1, 2 and 3 s. Frames are discrete; no motion is interpolated between them.';
 else
  candidates={'resSim','res','result','simulations_zono_fixed'};
  for n=1:numel(candidates)
   name=candidates{n};if ~isfield(d,name),continue;end;v=d.(name);
   if isstruct(v)&&isfield(v,'simulation'),v=v.simulation;end
   if iscell(v)&&~isempty(v)
    for j=1:min(5,numel(v))
     s=v{j};if ~isstruct(s)||~isfield(s,'t')||~isfield(s,'x'),continue;end
     t=s.t(:);x=s.x;
     if size(x,1)<=8&&size(x,2)==numel(t),x=x';end
     if size(x,1)==numel(t)+1
      x=x(2:end,:);alignment{end+1}='Removed the extra leading state stored before the continuous-time t/x pairs.';
     elseif size(x,1)~=numel(t)&&size(x,1)==numel(unique(t,'stable'))
      t=unique(t,'stable');alignment{end+1}='Discrete-time states aligned to the unique recorded event timestamps.';
     end
     assert(size(x,1)==numel(t),'Unresolved time alignment for %s',c.id);
     a.series{end+1}=trace(t,x(:,dims),'#c65729');
    end
    if ~isempty(a.series),break;end
   end
  end
  assert(~isempty(a.series),'No recorded trajectory for %s',c.id);
  starts=cellfun(@(s)s.samples(1,1),a.series);ends=cellfun(@(s)s.samples(end,1),a.series);a.times=[min(starts),max(ends)];
  if isfield(d,'terminalRegion'),a.staticSets{end+1}=struct('points',outline(d.terminalRegion.set,dims),'color','#43814b');
  elseif isfield(d,'T_zono_fixed'),a.staticSets{end+1}=struct('points',outline(d.T_zono_fixed.set,dims),'color','#43814b');
  elseif isfield(d,'T')&&isstruct(d.T)&&isfield(d.T,'set'),a.staticSets{end+1}=struct('points',outline(d.T.set,dims),'color','#43814b');
  elseif isfield(d,'Opts')&&isfield(d.Opts,'termReg'),a.staticSets{end+1}=struct('points',outline(d.Opts.termReg,dims),'color','#43814b');end
  a.note='Playback of up to five recorded MATLAB trajectories. Blue outlines show saved time-point sets; green shows the supplied terminal region when present. Playback speed is independent of computation time.';
  for name={'res','resLin','resExact'}
   if isfield(d,name{1})&&isstruct(d.(name{1}))&&isfield(d.(name{1}),'reachSetTimePoint')&&~isempty(d.(name{1}).reachSetTimePoint)
    sets=d.(name{1}).reachSetTimePoint;time=[];
    if strcmp(c.algorithm,'linSysMPC')||strcmp(c.algorithm,'reachsetMPC')
     % Reachset MPC has nonuniform update times. Read saved reachSet segment
     % boundaries, never infer uniform time from the number of sets.
     raw=fullfile(root,'research/remaining-run',c.id,'workspace.mat');
     if isfile(raw)
      s=load(raw,'res');pieces=s.res.reachSet;
      if numel(pieces)==numel(sets)-1
       time=0;for q=1:numel(pieces),time(end+1)=pieces(q).timePoint.time{end};end
      end
     end
    elseif isfield(d,'Param')&&isfield(d.Param,'tFinal')
     time=linspace(0,d.Param.tFinal,numel(sets));
    end
    for j=1:numel(sets)
     shape=struct('points',outline(sets{j},dims),'time',0);
     if isempty(time),shape.time=NaN;a.staticSets{end+1}=struct('points',shape.points,'color','#397cce');else,shape.time=time(j);a.sets{end+1}=shape;end
    end
    if isempty(time),a.note=[a.note,' Set timestamps are unavailable in the export: all set outlines remain static while the recorded trajectory advances.'];end
    break;
   end
  end
 end
 if ~isfield(a,'frames')
  cloud=[];for s=a.series,cloud=[cloud;s{1}.samples(:,2:3)];end
  for s=[a.sets,a.staticSets],cloud=[cloud;s{1}.points];end
  assert(~isempty(cloud)&&all(isfinite(cloud(:))),'Invalid geometry');
  lo=min(cloud,[],1);hi=max(cloud,[],1);pad=max(hi-lo,1e-5)*.08;
  a.bounds=[lo(1)-pad(1),hi(1)+pad(1),lo(2)-pad(2),hi(2)+pad(2)];
 end
 a.legend={struct('label','Saved reachable / terminal sets','color','#397cce'),struct('label','Recorded trajectory / measurement','color','#c65729')};
 if ~isempty(a.staticSets),a.legend{end+1}=struct('label','Terminal region / static set','color','#43814b');end
 if isfield(a,'frames'),a.legend={struct('label','Planned occupancy','color','#00a63b'),struct('label','Occupancy at shown time','color','#2451c8'),struct('label','Dynamic obstacle','color','#ea969d')};end
 if strcmp(a.timeKind,'sequence'),a.legend={struct('label','Linearization','color','#397cce'),struct('label','Polynomialization','color','#ba5339')};end
 a.geometryNote='Polyzonotopic geometry uses a 2D zonotopic display enclosure; ellipsoids use a sampled outline. Original PNG/SVG plots and MAT data retain the full representations.';
 a.alignmentNotes=unique(alignment);a.projectionDimensions=dims;a.source=['../results/full-suite/',c.id,'/plot-data.mat'];
 writejson(fullfile(out,[c.id,'.json']),a);
 audit{end+1}=struct('id',c.id,'series',numel(a.series),'sets',numel(a.sets),'staticSets',numel(a.staticSets),'projectionDimensions',dims,'alignmentNotes',{a.alignmentNotes});
 fprintf('ANIMATION EXPORTED %s\n',c.id);
end
writejson(fullfile(root,'research/animation-export-audit.json'),audit);
if ~renderScenes,return;end
% Render the four recorded planning snapshots, using the original plotting
% functions and saved objects. No planning or simulation is called.
s=load(fullfile(root,'research/remaining-run/example_maneuverAutomaton_car1/workspace.mat'),'MA','ind','x0','dynObs','lanelets');
for k=0:3
 f=figure('Visible','off','Color','w','Position',[100,100,1100,380]);hold on;box on;
 for j=1:numel(s.lanelets),plot(s.lanelets{j},[1,2],'FaceColor',[.92 .94 .96],'EdgeColor',[.55 .6 .65]);end
 plotPlannedTrajectory(s.MA,s.ind,s.x0,[],[0 .65 .2],'EdgeColor','none');
 plotPlannedTrajectory(s.MA,s.ind,s.x0,interval(k),[.1 .3 .8]);plotObstacles([],s.dynObs,interval(k));
 xlim([0,70]);xlabel('x [m]');ylabel('y [m]');title(sprintf('Recorded traffic plan · t = %d s',k));set(gca,'FontName','Arial','FontSize',15);
 print(f,fullfile(out,sprintf('maneuver-%d.svg',k)),'-dsvg');close(f);
end
end
function s=trace(t,x,color)
assert(all(diff(t)>=-1e-10)&&all(isfinite(x(:))));idx=unique(round(linspace(1,numel(t),min(450,numel(t)))));
s=struct('color',color,'samples',[t(idx),x(idx,:)]);
end
function p=outline(v,dims)
if iscell(v),v=v{1};end
if isfield(v,'set'),v=v.set;end
if isfield(v,'c')
 c=v.c(dims);G=v.G(dims,:);
 if isfield(v,'E')
  even=all(mod(v.E,2)==0,1);c=c+sum(G(:,even),2)/2;G(:,even)=G(:,even)/2;
 end
 if isfield(v,'GI'),G=[G,v.GI(dims,:)];end
 G=G(:,any(abs(G)>1e-13,1));flip=G(2,:)<0|(abs(G(2,:))<1e-13&G(1,:)<0);G(:,flip)=-G(:,flip);
 [~,order]=sort(atan2(G(2,:),G(1,:)));G=G(:,order);p=(c-sum(G,2)+[zeros(2,1),cumsum([2*G,-2*G],2)])';
elseif isfield(v,'lower')
 lo=v.lower(dims);hi=v.upper(dims);p=[lo';hi(1),lo(2);hi';lo(1),hi(2);lo'];
elseif isfield(v,'Q')
 [U,D]=eig(v.Q(dims,dims));angle=linspace(0,2*pi,65);p=(v.q(dims)+U*sqrt(max(D,0))*[cos(angle);sin(angle)])';
elseif isfield(v,'A')
 assert(size(v.A,2)==2,'Only 2D halfspace regions supported');p=[];
 for i=1:size(v.A,1),for j=i+1:size(v.A,1)
  A=v.A([i,j],:);if abs(det(A))<1e-12,continue;end;x=A\v.b([i,j]);if all(v.A*x<=v.b+1e-8),p(end+1,:)=x';end
 end,end
 assert(size(p,1)>=3);p=p(convhull(p(:,1),p(:,2)),:);
else,error('Unsupported geometry');end
if size(p,1)==1,p=repmat(p,3,1);end
end
function writejson(file,value)
fid=fopen(file,'w','n','UTF-8');fprintf(fid,'%s',jsonencode(value));fclose(fid);
end
