AROC full-suite reproduction
============================

The runner covers 18 representative examples from all 11 algorithm families
and the 20 script-based sections selected by upstream runUnitTests. Additional
nested function-style component tests are outside this record. It does not execute every benchmark
script in AROC. It preserves each selected example's benchmark parameters.
Allow substantial runtime and disk space for full MATLAB workspaces.

Extract this ZIP into an empty directory. Put the following dependencies in:
research/AROC    commit 6ba0295754d935b2bf540fab904ebc235a2d7a5c
research/CORA    v2026.0.1 (6cb79424fc4085c1af10a13236bcca9776887683)
research/YALMIP  R20250626 (61160192b05af3772980fad7137825ff1ea64eb2)
research/CasADi  3.7.2, matching the host platform and MATLAB binary format

Obtain dependencies from their official repositories/vendor releases:
https://github.com/TUMcps/AROC
https://github.com/TUMcps/CORA
https://github.com/yalmip/YALMIP
https://github.com/casadi/casadi/releases/tag/3.7.2
SeDuMi 1.3 is a separate installation; proprietary solver licenses are not included.
The recorded run used Windows MATLAB R2024b Update 9, Optimization Toolbox,
Symbolic Math Toolbox, Parallel Computing Toolbox, CasADi/IPOPT and SeDuMi 1.3.
Consult the AROC manual for the complete dependency requirements.

Apply local-changes.patch to the AROC checkout before running. It contains two
MOSEK-to-SeDuMi selections and the corrected platoon plot axis labels. No
constraint, tolerance, horizon, or iteration limit is relaxed by this patch.
The recorded MOSEK 11.0 installation returned LICENSE_EXPIRED (1001), so this
is a documented solver substitution rather than the stock MOSEK environment.

In MATLAB, from the extraction directory:
  setenv('AROC_SEDUMI_DIR','absolute path to your SeDuMi installation');
  addpath('research');
  run_full_suite;
  export_plot_data;

The manifest and logs are written to research/full-run. Calling run_full_suite
again resumes pending items. A failed case is skipped unless selected by its
exact ID, e.g. run_full_suite('example_linSysMPC_doubleIntegrator'). Archive the
case directory AND manifest before a retry; an explicit retry replaces its
status and appends to its log. Never launch concurrent runners sharing this
output directory or AROC generated files.

Example executed = script completed and listed sampled checks passed.
Test passed = original MATLAB test section passed. Neither a completed script
nor sampled checks alone are an independent formal proof. Inspect solver
warnings (including iteration limits), errors, and individual test outcomes.
Wall time includes checks, serialization, export and initial parallel startup;
it is not a controlled cross-algorithm performance comparison.

Each original full workspace stays local. export_plot_data writes portable
numeric time-point geometry and at most 10 recorded simulations per results
object, omitting continuous-time tubes. That display subset does not change
the sampled trajectories inspected by the runner. The separate three initial
website demonstrations have their own scripts and configurations.
