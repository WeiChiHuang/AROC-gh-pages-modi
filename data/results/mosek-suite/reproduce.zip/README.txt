MOSEK terminal-region rerun
==========================
This separate record executes 6 original terminal-region examples and the
4 script-based sections in unitTests/testTerminalRegion.m, retaining upstream
MOSEK selections and original benchmark settings. See WARNING-RESOLUTION.txt
for the validated CORA source-patch replacements included in the current page.

Place unmodified AROC commit 6ba0295754d935b2bf540fab904ebc235a2d7a5c in
research/AROC-mosek, and CORA v2026.0.1 commit
6cb79424fc4085c1af10a13236bcca9776887683 in research/CORA-mosek.
Use YALMIP R20250626 commit 61160192b05af3772980fad7137825ff1ea64eb2
in research/YALMIP, and CasADi 3.7.2 in research/CasADi.
Obtain dependencies from the official TUMcps/AROC, TUMcps/CORA,
yalmip/YALMIP and casadi/casadi GitHub repositories.

The recorded host uses MATLAB R2024b Update 9 and MOSEK 11.0 with a valid
personal academic license. Install MATLAB toolbox dependencies documented
in the AROC manual. Obtain and install your own MOSEK license; no license
is included. Start a fresh MATLAB process and set:
  setenv('AROC_MOSEK_TOOLBOX','absolute path to MOSEK toolbox/r2019b');
  addpath('research');
  run_mosek_suite;
  export_mosek_plot_data;

Outputs go to research/mosek-run. The isolated AROC/CORA directories avoid
generated-file conflicts with the broader SeDuMi batch. Do not run both
runners in one MATLAB process. Completed cases are skipped on resume;
archive prior evidence before explicitly selecting a case ID for retry.

Example execution and sampled checks are separate from the original tests.
Inspect individual failures, solver diagnostics and validation limits.
Plot-data exports contain time-point geometry and up to ten recorded
simulations, omitting continuous-time tubes. Full workspaces remain local.
Wall times include serialization, checks and exports and are not a controlled
performance comparison between solvers or algorithms.
