function test_abstraction_order_fix
setup_warning_fix;warning('off','backtrace');
root=fileparts(fileparts(mfilename('fullpath')));
before=fileread(fullfile(root,'research/CORA-mosek/contDynamics/@nonlinearSys/linReach_adaptive.m'));
after=fileread(fullfile(root,'research/CORA-warning-fix/contDynamics/@nonlinearSys/linReach_adaptive.m'));
before=section(before);after=section(after);rng(20261102,'twister');
matrices={zeros(3),[0 0 0;1 0 0;0 1 0],[0 0 0 0;1 0 0 0;0 1 0 0;0 0 0 0],[1 1;-1 -1]};
matched=0;removed=0;
for k=1:104
 if k<=4,A=matrices{k};else,A=randn(6).*(rand(6)>.6);end
 n=size(A,1);sigma=randi([0,3],n,1);mask=rand(n,1)>.5;
 if k==3,mask=[1;0;0;0];sigma=zeros(4,1);end
 [old,oldWarn]=evaluate(before,A,sigma,mask);
 [new,newWarn]=evaluate(after,A,sigma,mask);
 assert(isequal(old,new),'Abstraction orders changed for fixture %d',k);
 assert(~contains(newWarn,'Check computation for order of abstraction error'));
 if k==3,assert(isequal(new,[0;1;2;Inf]));end
 matched=matched+1;removed=removed+contains(oldWarn,'Check computation for order of abstraction error');
end
assert(removed>0,'No spurious warning was reproduced by the regression fixtures.');
report=struct('fixturesMatched',matched,'spuriousWarningsAvoided',removed,'ordersIncludingInfPreserved',true);
fid=fopen(fullfile(root,'research/abstraction-order-fix-check.json'),'w');fprintf(fid,'%s',jsonencode(report,PrettyPrint=true));fclose(fid);
disp(report);
end
function code=section(code)
start=strfind(code,'% express G as function');stop=strfind(code,'options.minorder = min(options.orders);');
stop=stop(stop>start(1));code=code(start(1):stop(1)+length('options.minorder = min(options.orders);')-1);
end
function [orders,message]=evaluate(code,A,sigma,mask)
n=size(A,1);Vdyn=zonotope(zeros(n,1),diag(double(mask)));options=struct; %#ok<NASGU>
lastwarn('');captured=evalc(code);[message,~]=lastwarn;message=[message,captured];orders=options.orders;
end
