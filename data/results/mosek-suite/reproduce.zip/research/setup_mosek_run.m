function setup_mosek_run(useMosek)
if nargin<1, useMosek=true; end
root=fileparts(fileparts(mfilename('fullpath')));
for name={'CORA-mosek','YALMIP','AROC-mosek'}
    folder=fullfile(root,'research',name{1});
    assert(isfolder(folder),'Missing dependency directory: %s',folder);
    addpath(genpath(folder));
end
addpath(fullfile(root,'research','CasADi'));
if useMosek
    folder=getenv('AROC_MOSEK_TOOLBOX');
else
    folder=getenv('AROC_SEDUMI_DIR');
end
assert(~isempty(folder) && isfolder(folder),'Set the selected solver directory environment variable first.');
addpath(genpath(folder));
set(groot,'defaultFigureVisible','off');
set(groot,'defaultAxesFontName','Arial','defaultAxesFontSize',12);
rng(20261019,'twister');
end
